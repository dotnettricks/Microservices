﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductService.Models;

namespace CatalogService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CatalogController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            //TODO: Access form database

            //For sample purpose
            List<Product> data = new List<Product>();
            data.Add(new Product { ProductId = 1, Name = "MVC Book", Description = "My MVC Book", UnitPrice = 120M });
            data.Add(new Product { ProductId = 2, Name = "Angular Book", Description = "My Angular Book", UnitPrice = 150M });

            return data;
        }
    }
}